<?php
/**
 * Created by PhpStorm.
 * User: Rémi
 * Date: 19/05/2015
 * Time: 15:21
 */
// include the prod configuration
require __DIR__.'/prod.php';

// enable the debug mode
$app['debug'] = true;